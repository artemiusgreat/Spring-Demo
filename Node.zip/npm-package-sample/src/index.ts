import $ from "jquery";
/*
export const myPackage = (taco = ''): string => {
  return `${taco} from my package`;
};
*/
export const scriptPackage = (taco = ''): JQueryStatic => {
  ($ as any).demo = "Yo";
  return $;
};
