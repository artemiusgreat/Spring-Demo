/// <reference types="jquery" />
export declare const scriptPackage: (taco?: string) => JQueryStatic;
