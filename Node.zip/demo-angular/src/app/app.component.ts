import { Component, OnInit } from '@angular/core';
import { scriptPackage } from "typescript-npm-package-template";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  title = 'demo-angular';

  ngOnInit(): void {
    const x = scriptPackage() as any;
    console.log(x.demo);
  }
}
